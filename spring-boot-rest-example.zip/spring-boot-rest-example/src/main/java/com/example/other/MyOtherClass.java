package com.example.other;

import com.example.java.MyClass;

public class MyOtherClass {

    public static void main (String[] args){

        MyClass myclass = new MyClass();
       // myclass.

    }
}
