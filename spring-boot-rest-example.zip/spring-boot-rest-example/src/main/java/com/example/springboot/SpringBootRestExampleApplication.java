package com.example.springboot;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootRestExampleApplication
{
 //GET , POST . PUT . DLETE
 //CURD /CRUD   /CRUDL
public static void main(String[] args) 
{
  SpringApplication.run(SpringBootRestExampleApplication.class, args);
}
}
