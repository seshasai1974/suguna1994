package com.example.java;

public class MyClass {

    private void method1(){

    }

    protected void method2(){

    }

    public void method3(){

    }
    public static void main (String[] args){
        MyClass myClass = new MyClass();

    }
}
